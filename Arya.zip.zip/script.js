var typed = new Typed(".multiple-text", {
    Strings: ["Web Developer", "Computer Network Engginering"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
})